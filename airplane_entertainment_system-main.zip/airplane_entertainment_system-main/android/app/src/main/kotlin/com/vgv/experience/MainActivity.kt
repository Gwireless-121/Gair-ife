package com.vgv.experience.airplane_entertainment_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
