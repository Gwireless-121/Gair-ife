# Music Visualizer Generator

[![style: very good analysis][very_good_analysis_badge]][very_good_analysis_link]
[![License: MIT][license_badge]][license_link]

Tool to generate visualizer data for music.

@Kirpal used this to generate the dummy visualizer data. If you want to hook up real audio data to the visualizer, you should reach out to him to discuss how this can be leveraged to convert actual audio data into a format suitable for the visualizer widget

---

[license_badge]: https://img.shields.io/badge/license-MIT-blue.svg
[license_link]: https://opensource.org/licenses/MIT
[very_good_analysis_badge]: https://img.shields.io/badge/style-very_good_analysis-B22C89.svg
[very_good_analysis_link]: https://pub.dev/packages/very_good_analysis
