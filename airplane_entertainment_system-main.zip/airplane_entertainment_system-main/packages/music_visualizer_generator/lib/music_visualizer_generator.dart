/// music_visualizer_generator, A Very Good Project created by Very Good CLI.
///
/// ```sh
/// # activate music_visualizer_generator
/// dart pub global activate music_visualizer_generator
///
/// # see usage
/// music_visualizer_generator --help
/// ```
library;
