/// UI package for the Airplane Entertainment System.
library;

export 'src/theme/theme.dart';
export 'src/widgets/widgets.dart';
