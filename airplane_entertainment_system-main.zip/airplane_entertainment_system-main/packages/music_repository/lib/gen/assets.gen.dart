/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

class $LibGen {
  const $LibGen();

  /// Directory path: lib/tracks
  $LibTracksGen get tracks => const $LibTracksGen();
}

class $LibTracksGen {
  const $LibTracksGen();

  /// File path: lib/tracks/Arpent.mp3
  String get arpent => 'lib/tracks/Arpent.mp3';

  /// File path: lib/tracks/Groovin.mp3
  String get groovin => 'lib/tracks/Groovin.mp3';

  /// File path: lib/tracks/Motions.mp3
  String get motions => 'lib/tracks/Motions.mp3';

  /// File path: lib/tracks/Trip Up North.mp3
  String get tripUpNorth => 'lib/tracks/Trip Up North.mp3';

  /// File path: lib/tracks/Windy Old Weather.mp3
  String get windyOldWeather => 'lib/tracks/Windy Old Weather.mp3';

  /// List of all assets
  List<String> get values =>
      [arpent, groovin, motions, tripUpNorth, windyOldWeather];
}

class Assets {
  Assets._();

  static const $LibGen lib = $LibGen();
}
