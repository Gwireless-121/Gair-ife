/// Repository of music tracks.
library;

export 'src/model/model.dart';
export 'src/music_repository.dart';
